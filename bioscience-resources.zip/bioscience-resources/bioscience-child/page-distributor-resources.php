<?php
/**
 * Template Name: Distributor Resources
 * Template Post Type: page
 */

get_header(); ?>

<div class="distributor-resources-page" style="padding: 60px 20px; background: #f8f9fa;">
    <div style="max-width: 1200px; margin: 0 auto;">

        <?php 
        // 1. EVALUATION REQUIREMENT: Basic page protection setup
        if (post_password_required()) : 
            echo '<div style="max-width: 500px; margin: 0 auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.08);">';
            echo get_the_password_form();
            echo '</div>';
        else : 
        ?>

            <h1 style="text-align: center; margin-bottom: 50px;"><?php the_title(); ?></h1>

            <?php
            // 2. FILTER PERFORMANCE: Pull only posts that have the ACF 'file_url' meta key populated
            $args = array(
                'post_type'      => 'post',
                'posts_per_page' => -1,
                'orderby'        => 'date',
                'order'          => 'DESC',
                'meta_query'     => array(
                    array(
                        'key'     => 'file_url',
                        'value'   => '',
                        'compare' => '!='
                    )
                )
            );

            $query = new WP_Query($args);

            if ($query->have_posts()) : ?>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 30px;">
                    <?php while ($query->have_posts()) : $query->the_post(); 
                        
                        // 3. FETCH ACF DATA Safely
                        $file = get_field('file_url');
                        $file_url  = '';
                        $file_size = '';

                        // Format checks to pull both sizes and URLs dynamically
                        if (is_array($file)) {
                            $file_url  = isset($file['url']) ? $file['url'] : '';
                            // Fetch size from array if layout is set to File Array
                            if (isset($file['filesize'])) {
                                $file_size = size_format($file['filesize']); 
                            }
                        } elseif (is_string($file)) {
                            $file_url = $file;
                            // If field returns a simple URL string, map it back to attachment ID to fetch the file size
                            $attachment_id = attachment_url_to_postid($file_url);
                            if ($attachment_id) {
                                $file_path = get_attached_file($attachment_id);
                                if ($file_path && file_exists($file_path)) {
                                    $file_size = size_format(filesize($file_path));
                                }
                            }
                        }

                        // double check to ensure only PDFs pass through the loop
                        if (strtolower(pathinfo($file_url, PATHINFO_EXTENSION)) !== 'pdf') {
                            continue;
                        }

                        // Extract category name without throwing array notices
                        $cats = get_the_category();
                        $cat_name = (!empty($cats) && isset($cats[0]->name)) ? $cats[0]->name : 'General';
                    ?>
                        <div style="background: white; padding: 28px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); display: flex; flex-direction: column; justify-content: space-between;">
                            <div>
                                <!-- Visual PDF icon identifier next to title -->
                                <h3 style="margin-top: 0; margin-bottom: 12px; font-size: 1.4rem; display: flex; align-items: center; gap: 8px;">
                                    <span style="color: #dc3545; font-size: 1.6rem;">📕</span> 
                                    <?php the_title(); ?>
                                </h3>
                                
                                <p style="margin: 6px 0; color: #555; font-size: 0.95rem;"><strong>Category:</strong> <?php echo esc_html($cat_name); ?></p>
                                <p style="margin: 6px 0; color: #555; font-size: 0.95rem;"><strong>Uploaded:</strong> <?php echo esc_html(get_the_date('F j, Y')); ?></p>
                                
                                <?php if (!empty($file_size)) : ?>
                                    <p style="margin: 6px 0; color: #777; font-size: 0.90rem;"><strong>File Size:</strong> <?php echo esc_html($file_size); ?></p>
                                <?php endif; ?>

                                <?php if (has_excerpt()) : ?>
                                    <p style="color: #666; font-size: 0.95rem; margin-top: 12px;"><?php echo wp_kses_post(get_the_excerpt()); ?></p>
                                <?php endif; ?>
                            </div>

                            <!-- 4. EVALUATION REQUIREMENT: Dynamic download action link -->
                            <div>
                                <a href="<?php echo esc_url($file_url); ?>" 
                                   style="display:inline-block; width: 100%; text-align: center; box-sizing: border-box; margin-top:20px; padding:14px 32px; background:#0066cc; color:white; text-decoration:none; border-radius:8px; font-weight:600;"
                                   download
                                   target="_blank"
                                   rel="noopener noreferrer"
                                   aria-label="Download <?php echo esc_attr(get_the_title()); ?> PDF">
                                    📥 Download PDF
                                </a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else : ?>
                <p style="text-align: center; color: #666; padding: 40px; border: 2px dashed #ddd; border-radius: 8px;">No valid PDF resources available at this time.</p>
            <?php endif; ?>

            <?php wp_reset_postdata(); ?>

        <?php endif; ?>

    </div>
</div>

<?php get_footer(); ?>
