<?php
/**
 * Bioscience Child Theme Functions
 */

// Enqueue child theme styles
function bioscience_child_styles() {
    wp_enqueue_style('bioscience-child-style', get_stylesheet_directory_uri() . '/style.css');
}
add_action('wp_enqueue_scripts', 'bioscience_child_styles');

// Optional: Force template refresh
function bioscience_flush_rewrites() {
    flush_rewrite_rules(false);
}
add_action('after_switch_theme', 'bioscience_flush_rewrites');